from selenium import webdriver
import time
from selenium.common import exceptions
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import random

friend_bot_uid_list = [
    '100003941261273',
]
class FacebookBot:
    def __init__(self,username,password,status_report=False):
        self.username = username
        self.password = password

        self.status_report = status_report

        chrome_options = Options()
        chrome_options.add_argument("--incognito")
        chrome_options.add_argument("--disable-notifications")

        if self.status_report: print("Opening chromedriver...")
        self.wd = webdriver.Chrome(chrome_options=chrome_options)
        if self.status_report: print("Logging in...")
        self.login()

    def login(self):
        self.wd.get("https://www.facebook.com/login")
        self.wd.find_element_by_id("email").send_keys(self.username)
        self.wd.find_element_by_id("pass").send_keys(self.password)
        self.wd.find_element_by_id("loginbutton").click()

    def convert_to_int(self,string):
        try:
            return int(string)
        except ValueError:
            if string.lower().endswith("k"):
                string = string[:-2]
                try:
                    return int(float(string)*1000)
                except ValueError:
                    return int(string)*1000

    def like_post(self, post):
        like_it = None
        try:
            like_it = post.find_element_by_xpath("//a[@class=' _6a-y _3l2t  _18vj']")
            like_it.click()
        except exceptions.ElementNotVisibleException:
            like_it = None
        except exceptions.NoSuchElementException:
            like_it = None
        finally:
            return True

    def comment_post(self, post):
        None

    def input_text(self):
        send_action = self.wd.find_element_by_xpath("//div[@class='_59v1']//*[@data-editor]")
        send_action.click()
        send_action.send_keys('HELLO WORLD???')
        send_action.send_keys(Keys.RETURN)
#        message = ActionChains(send_action)
#        message.send_keys('HIIIII DUC DEP TRAI')
#        message.perform()
#        message.send_keys(Keys.RETURN)

    def chat_message(self):
        try:
            open_chat_list = self.wd.find_element_by_xpath("//div[@class='_7jby']")
            open_chat_list.click()
            friend_list = self.wd.find_elements_by_xpath("//li[@class='_42fz']")
            friend_bot_list = []
            for friend in friend_list:
                friend_uid = friend.get_attribute("data-id")
                if friend_uid in friend_bot_uid_list:
                    friend_bot_list.append(friend)
                    friend.click()
                    # click chat frame and send message
                    self.input_text()
            print('xxx')
        except exceptions.ElementNotVisibleException:
            print('Chat Failed 1')
        except exceptions.NoSuchElementException:
            print('Chat Failed 2')
        return True

    def response_message(self):
        None

    def scroll_max_speed(self, begin, end):
        start_at = begin + 9
        while start_at <= end:
            self.wd.execute_script("window.scrollTo(%d, %d);" % (0, start_at))
            start_at += 9
        return True

    def scroll(self, page_end=100):
        find_elem = None
        post_throughed_count = 0
        scroll_from = 3
        scroll_limit = self.wd.execute_script("return document.body.scrollHeight")
        self.chat_message()
        time.sleep(20)
        while scroll_from <= scroll_limit:
            scroll_limit = self.wd.execute_script("return document.body.scrollHeight")
            self.wd.execute_script("window.scrollTo(%d, %d);" % (0, scroll_from))
            scroll_from += 3
            list_post = self.wd.find_elements_by_xpath("//div[@class='_5pcr userContentWrapper']")[post_throughed_count:]
            first_post = list_post[0]
            first_post_size_height = first_post.size['height']
            first_post_position_height = first_post.location['y']
            if abs(first_post_position_height - scroll_from) <= 50:
                time.sleep(5)  # Do it some thing in this post
                # check if like this post
                if random.choice([True, False]):
                    self.like_post(first_post)  # do like post
                # check if comment this post
                #if random.choice([True, False]):
                #    self.comment_post(first_post)  # do comment post
                #if random.choice([True, False]):
                #    self.chat_message()
                self.scroll_max_speed(scroll_from, scroll_from + first_post_size_height)
                scroll_from += first_post_size_height
                list_post.pop(0)
                post_throughed_count += 1

    def automate(self, unlike=False, page_end=100):
        if self.status_report: print("Forcing Facebook to load the posts...")
        self.scroll(page_end)
        #if self.status_report: print("Scrolled down %s times" % page_end)
        #if self.status_report: print("%s posts..." % ("Unliking" if unlike else "Liking"))
        #self.wd.execute_script("window.scrollTo(0,0);")
        #posts = self.get_posts()
        #num = 0
        #for p in posts:
        #    if p["likes"]["Angry"] == 0 and p["likes"]["Sad"] == 0 and p["likes"]["Like"] >= 5:
        #        article = p["article"]
        #        self.wd.execute_script("arguments[0].scrollIntoView();", article)
        #        button = article.find_element_by_class_name("UFILikeLink")
        #        if button.get_attribute("aria-pressed") == ("true" if unlike else "false"):
        #            num += 1
        #            self.wd.execute_script("arguments[0].click();",button)
        #            try:
        #                p = article.find_element_by_tag_name("p").get_attribute("innerText")
        #                p = p.replace("\n"," ").encode().decode("utf-8")
        #            except exceptions.NoSuchElementException:
        #                p = ""
        #            except:
        #                p = ""
        #            if self.status_report: print(' - %s "%s"' % ("Unliked" if unlike else "Liked",p))
        #if self.status_report: print("%s %s posts" % ("Unliked" if unlike else "Liked",num))

    def close(self):
        self.wd.close()


#username = input("Username: ")
#password = input("Password: ")

username = 'saadostores@gmail.com'
password = 'huynhduc95'

pages = 10
unlike = False
#pages = None
#while pages is False:
#    inp = input("How many pages to go through? (default 100, 'all' for whole News Feed): ")
#    if inp.isdigit():
#        pages = int(inp)
#    elif inp == "all":
#        pages = None


#unlike = None
#while unlike is None:
#    inp = input("Do you want to Like (l) or Unlike (u) posts? ")
#    if inp == "l":
#        unlike = False
#    elif inp == "u":
#        unlike = True

bot = FacebookBot(username,password,status_report=True)

bot.automate(unlike=unlike, page_end=pages)
print("Finished")
print()

input("Return to exit")
try:
    bot.close()
except:
    pass