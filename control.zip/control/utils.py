# This file contains all function that make all action for one normal FB user.

import time
import random

def true_or_false():
    return random.choice([True, False])
